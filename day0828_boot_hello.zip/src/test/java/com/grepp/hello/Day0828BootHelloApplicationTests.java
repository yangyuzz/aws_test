package com.grepp.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day0828BootHelloApplicationTests {

    @Test
    void contextLoads() {
    }

}
